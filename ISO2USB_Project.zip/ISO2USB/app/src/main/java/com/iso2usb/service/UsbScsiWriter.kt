package com.iso2usb.service

import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * USB Mass Storage Bulk-Only Transfer protokolü ile SCSI komutları gönderir.
 * Standart SCSI komut seti: INQUIRY, TEST UNIT READY, WRITE(10), SYNCHRONIZE CACHE(10)
 */
class UsbScsiWriter(
    private val connection: UsbDeviceConnection,
    private val epOut: UsbEndpoint,
    private val epIn: UsbEndpoint,
    private val timeout: Int = 5000
) {

    private var tag = 1

    // ── SCSI Komutları ────────────────────────────────────────────────────

    /** Cihaz bilgisi sorgula */
    fun inquiry() {
        val cdb = ByteArray(6).apply {
            this[0] = 0x12 // INQUIRY
            this[4] = 36   // allocation length
        }
        sendCommand(cdb, null, 36, isRead = true)
    }

    /** Cihazın hazır olup olmadığını kontrol et */
    fun testUnitReady() {
        val cdb = ByteArray(6) // TEST UNIT READY - tüm sıfır
        sendCommand(cdb, null, 0, isRead = true)
    }

    /**
     * WRITE(10): belirtilen blok adresine veri yaz
     * @param lba   Logical Block Address (başlangıç blok)
     * @param count Blok sayısı
     * @param data  Yazılacak veri tamponu
     * @param dataLen Gerçek veri uzunluğu (buffer daha büyük olabilir)
     */
    fun write10(lba: Long, count: Long, data: ByteArray, dataLen: Int) {
        val cdb = ByteArray(10).apply {
            this[0] = 0x2A.toByte() // WRITE(10)
            // LBA (4 byte, big-endian)
            this[2] = ((lba shr 24) and 0xFF).toByte()
            this[3] = ((lba shr 16) and 0xFF).toByte()
            this[4] = ((lba shr 8)  and 0xFF).toByte()
            this[5] = (lba          and 0xFF).toByte()
            // Transfer length (2 byte, big-endian)
            this[7] = ((count shr 8) and 0xFF).toByte()
            this[8] = (count         and 0xFF).toByte()
        }
        sendCommand(cdb, data, dataLen, isRead = false)
    }

    /** Cihaz tamponunu diske eşitle */
    fun synchronizeCache() {
        val cdb = ByteArray(10).apply {
            this[0] = 0x35 // SYNCHRONIZE CACHE(10)
        }
        sendCommand(cdb, null, 0, isRead = true)
    }

    // ── Bulk-Only Transfer ────────────────────────────────────────────────

    private fun sendCommand(cdb: ByteArray, data: ByteArray?, dataLen: Int, isRead: Boolean) {
        val currentTag = tag++

        // CBW (Command Block Wrapper) - 31 byte
        val cbw = buildCbw(currentTag, cdb, dataLen, isRead)
        bulkTransfer(epOut, cbw, cbw.size)

        // Data phase
        if (data != null && dataLen > 0) {
            if (isRead) {
                val buf = ByteArray(dataLen)
                bulkTransfer(epIn, buf, dataLen)
            } else {
                bulkTransfer(epOut, data, dataLen)
            }
        }

        // CSW (Command Status Wrapper) - 13 byte
        val csw = ByteArray(13)
        bulkTransfer(epIn, csw, 13)
        checkCsw(csw, currentTag)
    }

    private fun buildCbw(tag: Int, cdb: ByteArray, dataLen: Int, isRead: Boolean): ByteArray {
        val buf = ByteBuffer.allocate(31).order(ByteOrder.LITTLE_ENDIAN)
        buf.putInt(0x43425355) // dCBWSignature "USBC"
        buf.putInt(tag)
        buf.putInt(dataLen)
        buf.put(if (isRead) 0x80.toByte() else 0x00.toByte()) // bmCBWFlags
        buf.put(0x00) // bCBWLUN
        buf.put(cdb.size.toByte())
        buf.put(cdb)
        // Kalan byte'ları doldur (CBW 31 byte olmalı)
        repeat(16 - cdb.size) { buf.put(0) }
        return buf.array()
    }

    private fun checkCsw(csw: ByteArray, expectedTag: Int) {
        val sig    = ByteBuffer.wrap(csw, 0, 4).order(ByteOrder.LITTLE_ENDIAN).int
        val rTag   = ByteBuffer.wrap(csw, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
        val status = csw[12]

        if (sig != 0x53425355) throw IllegalStateException("Geçersiz CSW imzası")
        if (rTag != expectedTag) throw IllegalStateException("CSW tag uyumsuz")
        if (status != 0.toByte()) throw IllegalStateException("SCSI komut hatası: $status")
    }

    private fun bulkTransfer(endpoint: UsbEndpoint, buffer: ByteArray, length: Int) {
        var offset = 0
        while (offset < length) {
            val chunk = minOf(length - offset, endpoint.maxPacketSize * 64)
            val result = connection.bulkTransfer(endpoint, buffer, offset, chunk, timeout)
            if (result < 0) throw IllegalStateException("USB bulk transfer hatası (offset=$offset)")
            offset += result
        }
    }
}
