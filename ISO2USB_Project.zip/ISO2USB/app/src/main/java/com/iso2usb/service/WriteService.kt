package com.iso2usb.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.iso2usb.R
import com.iso2usb.util.ProgressBus
import kotlinx.coroutines.*
import java.io.InputStream
import java.io.RandomAccessFile
import kotlin.math.max

/**
 * ISO dosyasını USB'ye yazan arka plan servisi.
 *
 * Yazma yaklaşımı:
 *  1. UsbManager aracılığıyla UsbDeviceConnection al
 *  2. SCSI komutları (Bulk-Only Transfer) ile raw block yazma yap
 *     - Küçük ISO'lar için doğrudan bulk transfer
 *     - Android UsbRequest/UsbEndpoint API kullanılır
 *
 * NOT: Android 10+ üzerinde root gerektirmeksizin USB Mass Storage'e raw erişim
 * yalnızca SCSI komutları ile yapılabilir. Bu servis tam implementasyonu içerir.
 */
class WriteService : Service() {

    companion object {
        const val EXTRA_ISO_URI    = "iso_uri"
        const val EXTRA_USB_DEVICE = "usb_device"
        private const val CHANNEL_ID  = "iso2usb_write"
        private const val NOTIF_ID    = 1001
        private const val BLOCK_SIZE   = 512
        private const val TRANSFER_BUF = 512 * 1024 // 512 KB per chunk
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var usbManager: UsbManager

    override fun onCreate() {
        super.onCreate()
        usbManager = getSystemService(USB_SERVICE) as UsbManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val isoUriStr = intent?.getStringExtra(EXTRA_ISO_URI) ?: return START_NOT_STICKY
        val usbDevice = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_USB_DEVICE, UsbDevice::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_USB_DEVICE)
        } ?: return START_NOT_STICKY

        startForeground(NOTIF_ID, buildNotification("Başlatılıyor…", 0))

        scope.launch {
            runCatching {
                writeIsoToUsb(Uri.parse(isoUriStr), usbDevice)
            }.onFailure { e ->
                ProgressBus.postError(e.message ?: "Bilinmeyen hata")
                ProgressBus.postLog("HATA: ${e.message}")
            }
            stopSelf()
        }

        return START_NOT_STICKY
    }

    private suspend fun writeIsoToUsb(isoUri: Uri, device: UsbDevice) {
        ProgressBus.postLog("USB bağlantısı açılıyor…")

        val connection = usbManager.openDevice(device)
            ?: throw IllegalStateException("USB aygıtı açılamadı")

        // Mass Storage interface ve endpoint bul
        val usbInterface = findMassStorageInterface(device)
            ?: throw IllegalStateException("USB Mass Storage arayüzü bulunamadı")

        val claimed = connection.claimInterface(usbInterface, true)
        if (!claimed) throw IllegalStateException("USB arayüzü talep edilemedi")

        var bulkOut = usbInterface.getEndpoint(0) // OUT endpoint
        var bulkIn  = usbInterface.getEndpoint(1) // IN endpoint
        for (i in 0 until usbInterface.endpointCount) {
            val ep = usbInterface.getEndpoint(i)
            if (ep.direction == android.hardware.usb.UsbConstants.USB_DIR_OUT) bulkOut = ep
            if (ep.direction == android.hardware.usb.UsbConstants.USB_DIR_IN)  bulkIn  = ep
        }

        ProgressBus.postLog("USB Mass Storage arayüzü hazır")

        // ISO stream aç
        val isoStream: InputStream = contentResolver.openInputStream(isoUri)
            ?: throw IllegalStateException("ISO dosyası açılamadı")

        val isoSize = contentResolver.query(isoUri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getLong(c.getColumnIndexOrThrow(android.provider.OpenableColumns.SIZE))
            else -1L
        } ?: -1L

        ProgressBus.postLog("ISO boyutu: ${formatSize(isoSize)}")
        ProgressBus.postLog("SCSI komutları ile yazılıyor…")

        val usbWriter = UsbScsiWriter(connection, bulkOut, bulkIn)
        usbWriter.inquiry()
        usbWriter.testUnitReady()

        val totalBlocks = max(1, isoSize / BLOCK_SIZE)
        val buffer = ByteArray(TRANSFER_BUF)
        var blockOffset = 0L
        var bytesWritten = 0L
        val startTime = System.currentTimeMillis()

        isoStream.use { stream ->
            var read: Int
            while (stream.read(buffer).also { read = it } != -1) {
                val blocksToWrite = (read + BLOCK_SIZE - 1) / BLOCK_SIZE

                // Eksik kısmı sıfırla (son chunk için)
                if (read < buffer.size) buffer.fill(0, read, buffer.size)

                usbWriter.write10(blockOffset, blocksToWrite, buffer, read)

                blockOffset += blocksToWrite
                bytesWritten += read

                // İlerleme hesapla
                val percent = if (isoSize > 0) (bytesWritten * 100 / isoSize).toInt() else 0
                val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
                val speed = if (elapsed > 0) bytesWritten / elapsed else 0.0
                val remaining = if (speed > 0 && isoSize > 0) (isoSize - bytesWritten) / speed else 0.0

                ProgressBus.postProgress(
                    percent = percent,
                    speed = "${formatSize(speed.toLong())}/s",
                    eta = formatEta(remaining.toLong())
                )

                updateNotification("Yazılıyor… $percent%", percent)
                yield() // coroutine iptal edilebilsin
            }
        }

        // Sync / verify
        usbWriter.synchronizeCache()
        connection.releaseInterface(usbInterface)
        connection.close()

        ProgressBus.postLog("Yazma tamamlandı! Toplam: ${formatSize(bytesWritten)}")
        ProgressBus.postDone()
        updateNotification("Tamamlandı!", 100)
    }

    private fun findMassStorageInterface(device: UsbDevice) =
        (0 until device.interfaceCount)
            .map { device.getInterface(it) }
            .firstOrNull { it.interfaceClass == 8 } // USB_CLASS_MASS_STORAGE

    // ── Notification helpers ──────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "ISO Yazma",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "ISO dosyası USB'ye yazılırken gösterilir" }
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String, progress: Int): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ISO → USB")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_usb)
            .setProgress(100, progress, progress == 0)
            .setOngoing(true)
            .build()

    private fun updateNotification(text: String, progress: Int) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(text, progress))
    }

    private fun formatSize(bytes: Long) = when {
        bytes >= 1_073_741_824 -> "%.1f GB".format(bytes / 1_073_741_824.0)
        bytes >= 1_048_576     -> "%.1f MB".format(bytes / 1_048_576.0)
        else                   -> "%.1f KB".format(bytes / 1024.0)
    }

    private fun formatEta(seconds: Long) = when {
        seconds <= 0   -> ""
        seconds < 60   -> "${seconds}s"
        seconds < 3600 -> "${seconds / 60}d ${seconds % 60}s"
        else           -> "${seconds / 3600}sa ${(seconds % 3600) / 60}d"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
