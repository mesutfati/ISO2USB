package com.iso2usb.util

import androidx.lifecycle.MutableLiveData

/**
 * WriteService → ViewModel arası iletişim köprüsü (singleton LiveData)
 */
object ProgressBus {

    val progress = MutableLiveData<ProgressEvent>()
    val log      = MutableLiveData<String>()

    fun postProgress(percent: Int, speed: String, eta: String) {
        progress.postValue(ProgressEvent.Progress(percent, speed, eta))
    }

    fun postDone() {
        progress.postValue(ProgressEvent.Done)
    }

    fun postError(message: String) {
        progress.postValue(ProgressEvent.Error(message))
    }

    fun postLog(line: String) {
        log.postValue(line)
    }
}

sealed class ProgressEvent {
    data class Progress(val percent: Int, val speed: String, val eta: String) : ProgressEvent()
    object Done : ProgressEvent()
    data class Error(val message: String) : ProgressEvent()
}
