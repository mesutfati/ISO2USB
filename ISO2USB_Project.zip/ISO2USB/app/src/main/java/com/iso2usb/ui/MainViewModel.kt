package com.iso2usb.ui

import android.content.ContentResolver
import android.hardware.usb.UsbDevice
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

// ISO dosyası durumu
data class IsoState(
    val uri: Uri? = null,
    val name: String? = null,
    val size: Long? = null
)

// USB durumu
data class UsbState(
    val device: UsbDevice? = null,
    val name: String? = null,
    val size: Long? = null,
    val connected: Boolean = false
)

// Yazma durumu
sealed class WriteState {
    object Idle : WriteState()
    data class Writing(val percent: Int, val speed: String, val eta: String) : WriteState()
    object Done : WriteState()
    data class Error(val message: String) : WriteState()
}

class MainViewModel : ViewModel() {

    val isoState = MutableLiveData(IsoState())
    val usbState = MutableLiveData(UsbState())
    val writeState = MutableLiveData<WriteState>(WriteState.Idle)
    val logLine = MutableLiveData<String>()

    fun onIsoSelected(uri: Uri, resolver: ContentResolver) {
        var name: String? = null
        var size: Long? = null

        resolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIdx >= 0) name = cursor.getString(nameIdx)
                if (sizeIdx >= 0) size = cursor.getLong(sizeIdx)
            }
        }

        isoState.value = IsoState(uri = uri, name = name ?: "iso_file.iso", size = size)
        addLog("ISO seçildi: $name (${size?.let { formatSize(it) } ?: "?"})")
    }

    fun onUsbPermissionGranted(device: UsbDevice) {
        val name = device.productName ?: device.deviceName
        // Kapasite almak için native erişim gerekiyor, servis tarafında yapılır
        usbState.value = UsbState(device = device, name = name, connected = true)
        addLog("USB bağlandı: $name")
    }

    fun onUsbDetached() {
        usbState.value = UsbState()
        addLog("USB çıkarıldı")
        if (writeState.value is WriteState.Writing) {
            writeState.value = WriteState.Error("USB bağlantısı kesildi!")
        }
    }

    fun onWriteStarted() {
        writeState.value = WriteState.Writing(0, "Başlatılıyor…", "")
        addLog("Yazma başlatıldı…")
    }

    fun canStart(): Boolean =
        isoState.value?.uri != null &&
        usbState.value?.connected == true &&
        writeState.value is WriteState.Idle

    fun addLog(line: String) {
        logLine.value = line
    }

    private fun formatSize(bytes: Long): String {
        return when {
            bytes >= 1_073_741_824 -> "%.1f GB".format(bytes / 1_073_741_824.0)
            bytes >= 1_048_576    -> "%.1f MB".format(bytes / 1_048_576.0)
            else                   -> "%.1f KB".format(bytes / 1024.0)
        }
    }
}
