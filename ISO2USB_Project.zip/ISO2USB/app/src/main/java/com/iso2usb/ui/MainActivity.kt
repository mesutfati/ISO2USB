package com.iso2usb.ui

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.snackbar.Snackbar
import com.iso2usb.databinding.ActivityMainBinding
import com.iso2usb.service.WriteService
import com.iso2usb.util.SizeUtil

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var vm: MainViewModel
    private lateinit var usbManager: UsbManager

    companion object {
        private const val ACTION_USB_PERMISSION = "com.iso2usb.USB_PERMISSION"
    }

    // ISO dosyası seçici
    private val isoPickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { vm.onIsoSelected(it, contentResolver) }
    }

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                ACTION_USB_PERMISSION -> {
                    val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                    }
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        device?.let { vm.onUsbPermissionGranted(it) }
                    } else {
                        showSnackbar(getString(android.R.string.cancel))
                    }
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                    val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                    }
                    device?.let { requestUsbPermission(it) }
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    vm.onUsbDetached()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        usbManager = getSystemService(USB_SERVICE) as UsbManager
        vm = ViewModelProvider(this)[MainViewModel::class.java]

        setupUI()
        observeViewModel()
        registerReceivers()
        checkAlreadyConnectedUsb()

        // Eğer uygulama USB intent ile açıldıysa
        intent?.let { handleUsbIntent(it) }
    }

    private fun setupUI() {
        binding.btnSelectIso.setOnClickListener {
            isoPickerLauncher.launch("application/octet-stream")
        }

        binding.btnStart.setOnClickListener {
            showWarningDialog()
        }
    }

    private fun observeViewModel() {
        vm.isoState.observe(this) { state ->
            binding.tvIsoName.text = state.name ?: getString(com.iso2usb.R.string.no_iso)
            binding.tvIsoSize.text = state.size?.let { SizeUtil.format(it) } ?: ""
            updateStartButton()
        }

        vm.usbState.observe(this) { state ->
            binding.tvUsbName.text = state.name ?: getString(com.iso2usb.R.string.no_usb)
            binding.tvUsbSize.text = state.size?.let { SizeUtil.format(it) } ?: ""
            binding.ivUsbStatus.setColorFilter(
                getColor(if (state.connected) com.iso2usb.R.color.success else com.iso2usb.R.color.text_secondary)
            )
            binding.usbIndicator.setBackgroundResource(
                if (state.connected) com.iso2usb.R.drawable.circle_indicator_green
                else com.iso2usb.R.drawable.circle_indicator
            )
            updateStartButton()
        }

        vm.writeState.observe(this) { state ->
            when (state) {
                is WriteState.Idle -> {
                    binding.cardProgress.visibility = View.GONE
                    binding.btnStart.isEnabled = vm.canStart()
                    binding.btnStart.text = getString(com.iso2usb.R.string.start_write)
                }
                is WriteState.Writing -> {
                    binding.cardProgress.visibility = View.VISIBLE
                    binding.progressBar.progress = state.percent
                    binding.tvProgressPercent.text = "${state.percent}%"
                    binding.tvSpeed.text = state.speed
                    binding.tvEta.text = state.eta
                    binding.btnStart.isEnabled = false
                    binding.btnStart.text = getString(com.iso2usb.R.string.writing)
                }
                is WriteState.Done -> {
                    binding.progressBar.progress = 100
                    binding.tvProgressPercent.text = "100%"
                    binding.tvProgressLabel.text = getString(com.iso2usb.R.string.done)
                    binding.btnStart.isEnabled = true
                    binding.btnStart.text = getString(com.iso2usb.R.string.start_write)
                    showSnackbar("✓ ${getString(com.iso2usb.R.string.done)}")
                }
                is WriteState.Error -> {
                    binding.cardProgress.visibility = View.GONE
                    binding.btnStart.isEnabled = true
                    showSnackbar("✗ ${state.message}")
                }
            }
        }

        vm.logLine.observe(this) { line ->
            binding.tvLog.append("$line\n")
            binding.scrollLog.post {
                binding.scrollLog.fullScroll(View.FOCUS_DOWN)
            }
        }
    }

    private fun registerReceivers() {
        val filter = IntentFilter().apply {
            addAction(ACTION_USB_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(usbReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(usbReceiver, filter)
        }
    }

    private fun checkAlreadyConnectedUsb() {
        usbManager.deviceList.values.firstOrNull { isMassStorage(it) }?.let {
            requestUsbPermission(it)
        }
    }

    private fun handleUsbIntent(intent: Intent) {
        if (intent.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) {
            val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
            }
            device?.let { requestUsbPermission(it) }
        }
    }

    private fun requestUsbPermission(device: UsbDevice) {
        if (usbManager.hasPermission(device)) {
            vm.onUsbPermissionGranted(device)
        } else {
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(this, 0,
                Intent(ACTION_USB_PERMISSION), flags)
            usbManager.requestPermission(device, pi)
        }
    }

    private fun isMassStorage(device: UsbDevice): Boolean {
        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            if (intf.interfaceClass == 8) return true // USB_CLASS_MASS_STORAGE
        }
        return false
    }

    private fun showWarningDialog() {
        AlertDialog.Builder(this)
            .setTitle(getString(com.iso2usb.R.string.warning_title))
            .setMessage(getString(com.iso2usb.R.string.warning_message))
            .setPositiveButton(getString(com.iso2usb.R.string.yes)) { _, _ ->
                startWriting()
            }
            .setNegativeButton(getString(com.iso2usb.R.string.cancel), null)
            .show()
    }

    private fun startWriting() {
        val isoUri = vm.isoState.value?.uri ?: return
        val usbDevice = vm.usbState.value?.device ?: return

        val intent = Intent(this, WriteService::class.java).apply {
            putExtra(WriteService.EXTRA_ISO_URI, isoUri.toString())
            putExtra(WriteService.EXTRA_USB_DEVICE, usbDevice)
        }
        startService(intent)
        vm.onWriteStarted()
    }

    private fun updateStartButton() {
        binding.btnStart.isEnabled = vm.canStart()
    }

    private fun showSnackbar(msg: String) {
        Snackbar.make(binding.root, msg, Snackbar.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(usbReceiver)
    }
}
