# ISO 2 USB — Reklamsız Temiz Uygulama

## 📱 Uygulama Hakkında
ISO dosyalarını Android OTG USB sürücülerine yazan, reklamsız ve sade tasarımlı bir uygulama.

## ⚙️ Nasıl Çalışır?
1. ISO dosyasını seç (Dosya Yöneticisi aracılığıyla)
2. USB flash belleği Android telefona OTG adaptörü ile tak
3. "Yazmaya Başla" butonuna bas
4. USB'deki TÜM veri silinir, ISO içeriği yazılır

## 🔧 Teknik Detaylar
- **USB Erişimi:** Android USB Host API (root gerekmez)
- **Yazma Protokolü:** SCSI Bulk-Only Transfer (BOT) — USB Mass Storage standartı
- **Minimum Android:** API 26 (Android 8.0)
- **Root gereksinimi:** YOK

## 🏗️ Derleme

### Gereksinimler
- Android Studio Hedgehog (2023.1.1) veya üstü
- JDK 17
- Android SDK 34

### Adımlar
```bash
# Projeyi Android Studio'da aç
File → Open → ISO2USB klasörü seç

# Veya komut satırından:
./gradlew assembleRelease
```

## 📂 Proje Yapısı
```
ISO2USB/
├── app/src/main/
│   ├── java/com/iso2usb/
│   │   ├── ui/
│   │   │   ├── MainActivity.kt      ← Ana ekran
│   │   │   └── MainViewModel.kt     ← Durum yönetimi
│   │   ├── service/
│   │   │   ├── WriteService.kt      ← USB yazma servisi
│   │   │   └── UsbScsiWriter.kt     ← SCSI komutları
│   │   └── util/
│   │       ├── ProgressBus.kt       ← Servis↔UI iletişim
│   │       └── SizeUtil.kt          ← Boyut formatlama
│   ├── res/
│   │   ├── layout/activity_main.xml ← Arayüz
│   │   ├── values/themes.xml        ← Renkler & tema
│   │   └── xml/device_filter.xml    ← USB cihaz filtresi
│   └── AndroidManifest.xml
```

## ⚠️ Dikkat
- USB'ye yazma işlemi USB'deki TÜM veriyi siler
- İşlem sırasında USB'yi çıkarmayın
- Büyük ISO dosyaları için yeterli pil seviyesi gerekir

## 🎨 Tasarım Felsefesi
- **Reklam yok** — tamamen temiz
- **Sade UI** — sadece gerekli elementler
- **Dark log** — işlem günlüğü için göz dostu koyu panel
- **Material Design 3** bileşenleri
